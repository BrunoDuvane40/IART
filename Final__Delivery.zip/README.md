# IART
Repositório Projeto Inteligência Artificial 

To run the project 

First use pip/pip3 install matplotlib to be able to see the route generated 

Run using python/python3 Menu.py  